# 📁 fayl: train_pipeline.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
import dill

# 1. Ma'lumotni yuklaymiz (namuna df)
data = {
    'gender': ['Ayol', 'Erkak'],
    'SeniorCitizen': [0, 1],
    'Partner': ['Ha', 'Yo‘q'],
    'Dependents': ['Yo‘q', 'Ha'],
    'tenure': [1, 20],
    'PhoneService': ['Ha', 'Yo‘q'],
    'MultipleLines': ['Yo‘q', 'Ha'],
    'InternetService': ['DSL', 'Fiber optic'],
    'OnlineSecurity': ['Yo‘q', 'Ha'],
    'OnlineBackup': ['Ha', 'Yo‘q'],
    'DeviceProtection': ['Yo‘q', 'Ha'],
    'TechSupport': ['Yo‘q', 'Ha'],
    'StreamingTV': ['Yo‘q', 'Ha'],
    'StreamingMovies': ['Yo‘q', 'Ha'],
    'Contract': ['Oyma-oy', 'Bir yillik'],
    'PaperlessBilling': ['Ha', 'Yo‘q'],
    'PaymentMethod': ['Elektron chek', 'Kredit karta (avtomatik)'],
    'MonthlyCharges': [25.5, 80.9],
    'TotalCharges': [25.5, 1600.0],
    'Churn': [0, 1]
}
df = pd.DataFrame(data)

# 2. Targetni ajratamiz
X = df.drop(columns=["Churn"])
y = df["Churn"]

# 3. Ustunlar
cat_cols = ['gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
            'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
            'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
            'PaperlessBilling', 'PaymentMethod']
num_cols = ['tenure', 'MonthlyCharges', 'TotalCharges']

# 4. Preprocessor
preprocessor = ColumnTransformer(transformers=[
    ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols),
    ('num', StandardScaler(), num_cols)
])

# 5. Pipeline
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier())
])

# 6. Fit
pipeline.fit(X, y)

# 7. Saqlash
with open("pipeline.pkl", "wb") as f:
    dill.dump(pipeline, f)

print("✅ pipeline.pkl yaratildi")


