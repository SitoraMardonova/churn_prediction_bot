from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import dill

# ✅ FastAPI ilova
app = FastAPI()

# ✅ CORS ruxsat berish
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Hamma manzildan ruxsat
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Modelni yuklash
with open("pipeline.pkl", "rb") as f:
    pipeline = dill.load(f)

# ✅ Input modeli
class CustomerData(BaseModel):
    gender: str
    SeniorCitizen: int
    Partner: str
    Dependents: str
    tenure: int
    PhoneService: str
    MultipleLines: str
    InternetService: str
    OnlineSecurity: str
    OnlineBackup: str
    DeviceProtection: str
    TechSupport: str
    StreamingTV: str
    StreamingMovies: str
    Contract: str
    PaperlessBilling: str
    PaymentMethod: str
    MonthlyCharges: float
    TotalCharges: float

# ✅ Bashorat endpoint
@app.post("/predict")
def predict(data: CustomerData):
    df = pd.DataFrame([data.dict()])
    prediction = pipeline.predict(df)[0]
    probas = pipeline.predict_proba(df)[0]
    return {
        "prediction": int(prediction),
        "churn_probability": float(probas[1]),
        "stay_probability": float(probas[0])
    }







